© 2020 WeAreDevs
A distribution of https://wearedevs.net/scripts
June 13, 2020

*Make sure your anti-virus is not deleting the needed files! You may need to disable your anti-virus or find a way
to whitelist this folder. There should always be files called, "exploit-main.dll", "Gravity Switch.exe", and "WeAreDevs_API.dll"
*This is not a virus! Anti-viruses assume that because this is modifying your game. It is unusual behavior, but we assure your
that this is safe.

Step 1: Join any game
Step 2: Click the inject button when the game is fully loaded
Step 3: Click the newly appeared start button
Step 4: Press "e" while in game to turn off gravity